package com.example.marketing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketingApplicationTests {

    @Test
    void contextLoads() {
    }

}
